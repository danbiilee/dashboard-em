import Bottom from "./Bottom";

export default Bottom;
