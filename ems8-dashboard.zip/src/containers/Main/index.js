import Main from "./Main";
import Top from "./Top";
import Bottom from "./Bottom";

Main.Top = Top;
Main.Bottom = Bottom;

export default Main;
