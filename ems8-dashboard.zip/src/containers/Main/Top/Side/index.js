import Side from "./Side";

export default Side;
