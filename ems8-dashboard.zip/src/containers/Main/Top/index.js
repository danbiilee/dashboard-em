import Top from "./Top";
import Side from "./Side";
import Center from "./Center";

Top.Side = Side;
Top.Center = Center;

export default Top;
