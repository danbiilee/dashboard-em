import Center from "./Center";

export default Center;
