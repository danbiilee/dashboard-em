import React from "react";

const Topology = () => {
  return <h1>Topology</h1>;
};

export default Topology;
