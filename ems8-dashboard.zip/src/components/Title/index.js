import Title from "./Title";

export default Title;
