import React from "react";

const Grid = () => {
  return <h1>Grid</h1>;
};

export default Grid;
