import React from "react";

const NMSPage = () => {
  return <div>NMSPage</div>;
};

export default NMSPage;
