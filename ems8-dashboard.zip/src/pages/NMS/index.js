import NMS from "./NMSPage";

export default NMS;
