import SMS from "./SMSPage";

export default SMS;
